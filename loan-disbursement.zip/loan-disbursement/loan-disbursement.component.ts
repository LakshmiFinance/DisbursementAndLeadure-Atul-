import { Component, OnInit } from '@angular/core';
import { AccountHead } from '../modelpojo/account-head';
import { CommonService } from '../shared/common.service';

@Component({
  selector: 'app-loan-disbursement',
  templateUrl: './loan-disbursement.component.html',
  styleUrls: ['./loan-disbursement.component.css']
})
export class LoanDisbursementComponent implements OnInit {
  ldt:AccountHead[];
  buttenText:string="Disburse"
  constructor(private _common:CommonService)
  {
    this._common.getAccountData().subscribe((list=>{
      this.ldt=list;
    }))
   }

  ngOnInit(): void {
  }
  disburse()
  {
    this.buttenText="Processing";

  }

}
