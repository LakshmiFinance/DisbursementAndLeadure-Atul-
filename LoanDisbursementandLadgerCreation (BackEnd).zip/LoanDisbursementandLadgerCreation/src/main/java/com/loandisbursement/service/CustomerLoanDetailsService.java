package com.loandisbursement.service;

import java.util.List;

import com.loandisbursement.model.CustomerLoanDetails;

public interface CustomerLoanDetailsService 
{

	List<CustomerLoanDetails> getDetails();
	

}
