import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-emi-repayment-receipt',
  templateUrl: './emi-repayment-receipt.component.html',
  styleUrls: ['./emi-repayment-receipt.component.css']
})
export class EmiRepaymentReceiptComponent implements OnInit {
repaymentForm:FormGroup;

  constructor(private _fb:FormBuilder,private _common:CommonService) { }

  ngOnInit(): void {

    this.repaymentForm=this._fb.group({

    invoiceId:[''],
    emiPayDate:[''],
    customerName:[''],
    modeOfRepayment:[''],
    totalEmi:[''],
    remainingEmi:[''],
    transectionId:[''],
    loanId:[''],
    disbursementDate:[''],
    categoryOfLoan:['']
})
  }

  submit()
  {
    console.log(this.repaymentForm.value);
    this._common.saveemireceipt(this.repaymentForm.value).subscribe(res=>{})
  }
}
