import { Component, OnInit ,ViewChild,ElementRef} from '@angular/core';
import { jsPDF} from "jspdf"
import { CommonService } from '../common.service';
import { EmiRepaymentReceipt } from "../MODELPOJO/emi-repayment-receipt";
@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  @ViewChild('content',{static:false}) el!:ElementRef;
  constructor(private common:CommonService) { }

  invoice:EmiRepaymentReceipt;
  answer: number;
  ngOnInit(): void {

   
  }

  makePDF()
  {
    let pdf=new jsPDF('p','pt','a4');
    pdf.html(this.el.nativeElement,{callback:(pdf)=>{
      pdf.save("Invoice.pdf");
    }})
    
  }
  clickme(){
    this.common.getInvoice(this.answer).subscribe(res=>{
      this.invoice=res;
      console.log(res);
      
    })
   // console.log(this.answer);
  }
  
}
