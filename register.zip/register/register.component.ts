import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  myForm:FormGroup;
  constructor(private _fb:FormBuilder,private _http:HttpClient) { }

  ngOnInit(): void {


    this.myForm=this._fb.group({
     
      username:[''],
      password:[''],
      loanDisbursementMaster: this._fb.group({

            loanDisbursementMId:[''],
	          loanType:[''],
	          amountPayType:[''],
	          bankName:[''],
         	 accountNumber:[''],
	         ifscCode:[''],
	          accountType:[''],
	         transferAmount:[''],
         	 paymentStatus:[''],
        	 amountPaidDate:[''],
          }),

          loanDisbursementDetails:this._fb.group({

            loanDisbursementId:[''],
            loanMasterDetailsId:[''],
            loanId:[''],
	           loanAmount:[''],
             loanType:['']
          }),
          ledgerCreation:this._fb.group({
            lcid:[''],
            processingFee:[''],
            totalInterest:[''],
            numberOfMonth:[''],
            sanctionDate:[''],
            status:['']
          }),
          customerLoanDetails:this._fb.group({
            loanId:[''],
           loanCode:[''],
           customerName:[''],
           loanType:[''],
           loanAmount:[''],
           rateofInterest:['']
          }),
          loanCalculationEmi:this._fb.group({
            lcEmiId:[''],
            emiAmount:[''],
            emiInterest:[''],
            totalEmi:[''],
            startDate:['']
          })
    })
  }

  submit()
   {
    console.log(this.myForm.value);
    this._http.post("http://localhost:8095/Register",this.myForm.value).subscribe(res=>{});
     
   }

}
