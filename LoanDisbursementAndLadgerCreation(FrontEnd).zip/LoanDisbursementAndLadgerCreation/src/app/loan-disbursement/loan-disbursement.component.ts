import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { AccountHead } from '../MODELPOJO/account-head';
import { CustomerLoanDetails } from '../MODELPOJO/customer-loan-details';

@Component({
  selector: 'app-loan-disbursement',
  templateUrl: './loan-disbursement.component.html',
  styleUrls: ['./loan-disbursement.component.css']
})
export class LoanDisbursementComponent implements OnInit {
  ldt:AccountHead[];
  isHide:string="Disburse";
  constructor(private _http:HttpClient,private comman:CommonService) 
  {
   
   this.comman.getAllLoandisbus().subscribe(list=>{
    this.ldt=list;
})
   }

  ngOnInit(): void {
  }

  disburse(l)
{
  this.isHide="Disbused";
  
  
  }
  deletedata(){}
}


