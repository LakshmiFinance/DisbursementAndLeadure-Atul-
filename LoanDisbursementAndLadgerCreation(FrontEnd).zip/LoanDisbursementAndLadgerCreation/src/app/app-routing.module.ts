import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmiRepaymentReceiptComponent } from './emi-repayment-receipt/emi-repayment-receipt.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { LoanDisbursementComponent } from './loan-disbursement/loan-disbursement.component';
import { LoginComponent } from './login/login.component';
import { LoanDisbursementDetails } from './MODELPOJO/loan-disbursement-details';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'' ,redirectTo:'login', pathMatch:'full'},
  {path:'login', component:LoginComponent},
  {path:'register', component:RegisterComponent},
  {path:'LoanDisbursement', component:LoanDisbursementComponent},
  {path:'Emirepayment', component:EmiRepaymentReceiptComponent},
  {path:'invoice', component:InvoiceComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
