import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-emi-repayment-receipt',
  templateUrl: './emi-repayment-receipt.component.html',
  styleUrls: ['./emi-repayment-receipt.component.css']
})
export class EmiRepaymentReceiptComponent implements OnInit {
  repaymentForm:FormGroup; 
  constructor(private fb:FormBuilder,private common:CommonService) { 

  }

  ngOnInit(): void 
  {
    this.repaymentForm=this.fb.group({

    invoiceId:[''],
    emiPayDate:[''],
    customerName:[''],
    modeOfRepayment:[''],
    totalEmi:[''],
    remainingEmi:[''],
    transectionId:[''],
    loanId:[''],
    disbursementDate:[''],
    categoryOfLoan:['']

    })
  }

  submit()
  {
    console.log(this.repaymentForm.value);
    this.common.saveemireceipt(this.repaymentForm.value).subscribe(res=>{})
    
  }

}
