import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmiRepaymentReceiptComponent } from './emi-repayment-receipt.component';

describe('EmiRepaymentReceiptComponent', () => {
  let component: EmiRepaymentReceiptComponent;
  let fixture: ComponentFixture<EmiRepaymentReceiptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmiRepaymentReceiptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmiRepaymentReceiptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
