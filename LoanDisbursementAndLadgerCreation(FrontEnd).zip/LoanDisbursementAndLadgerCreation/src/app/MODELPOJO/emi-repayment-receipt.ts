import { AccountHead } from "./account-head";

export class EmiRepaymentReceipt 
{
    invoiceId:number;
    emiPayDate:string;
    customerName:string;
    modeOfRepayment:string;
    totalEmi:number;
    remainingEmi:number;
    transectionId:number;
    loanId:number;
    disbursementDate:string;
    categoryOfLoan:string;

    accountHead:AccountHead;
}
