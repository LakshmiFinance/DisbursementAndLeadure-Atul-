
export class LoanDisbursementDetails 
{
    loanDisbursementId:number;
    loanMasterDetailsId:number;
    loanId:number;
	 loanAmount:number;
     loanType:string;

}
