import { CustomerLoanDetails } from "./customer-loan-details";
import { EmiRepaymentReceipt } from "./emi-repayment-receipt";
import { LedgerCreation } from "./ledger-creation";
import { LoanCalculationEmi } from "./loan-calculation-emi";
import { LoanDisbursementDetails } from "./loan-disbursement-details";
import { LoanDisbursementMaster } from "./loan-disbursement-master";

export class AccountHead 
{
    accountHeadId:number;
    username:string;
    password:string;
    loanDisbursementMaster:LoanDisbursementMaster;
    loanDisbursementDetails:LoanDisbursementDetails;
    
    ledgerCreation:LedgerCreation;
    customerLoanDetails:CustomerLoanDetails;
    loanCalculationEmi:LoanCalculationEmi;

}
