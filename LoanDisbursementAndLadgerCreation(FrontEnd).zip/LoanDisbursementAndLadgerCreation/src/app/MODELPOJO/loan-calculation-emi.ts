export class LoanCalculationEmi 
{
	  lcEmiId:number;
    emiAmount:number;
    emiInterest:number;
    totalEmi:number;
    startDate:string;
}
