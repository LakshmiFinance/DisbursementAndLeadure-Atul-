export class LedgerCreation 
{
	lcid:number;
    processingFee:number;
    totalInterest:number;
    numberOfMonth:number;
    sanctionDate:string;
    status:string;
    
}
