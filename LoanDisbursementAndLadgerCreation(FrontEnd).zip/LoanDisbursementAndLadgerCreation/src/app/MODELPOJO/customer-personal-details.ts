export class CustomerPersonalDetails 
{
    cId:number;                                
	customerName:string;
	customerGender;
	customerMoblieNo:number;
	customerLoanAmount:number;
	customerAge:number;
	customerDoB:string;
	customerEmail:string;
	customerPancardNo:string;
}
