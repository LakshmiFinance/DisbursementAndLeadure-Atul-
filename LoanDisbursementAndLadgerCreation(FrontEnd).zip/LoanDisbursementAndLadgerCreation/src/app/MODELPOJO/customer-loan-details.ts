import { LedgerCreation } from "./ledger-creation";

export class CustomerLoanDetails 
{
    loanId:number;
    loanCode:number;
    customerName:string;
    loanType:string;
    loanAmount:number;
    rateofInterest:number;
}
