export class LoanDisbursementMaster 
{

    loanDisbursementMId:number;
	 loanType:string;
	 amountPayType:string;
	 bankName:string;
	 accountNumber:number;
	 ifscCode:string;
	 accountType:string;
	 transferAmount:number;
	 paymentStatus:boolean;
	 amountPaidDate:string;


}
