import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, observable } from 'rxjs';
import { AccountHead } from './MODELPOJO/account-head';
import { CustomerLoanDetails } from './MODELPOJO/customer-loan-details';
import { EmiRepaymentReceipt } from './MODELPOJO/emi-repayment-receipt';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private httpclient:HttpClient) {
  }
  getcustomerList():Observable<CustomerLoanDetails[]>
  {
    return this.httpclient.get<CustomerLoanDetails[]>("http://localhost:9093/getAllloanDet");
  }

  getAllLoandisbus():Observable<AccountHead[]>
  {
    return this.httpclient.get<AccountHead[]>("http://localhost:9093/getAllAccountHead")
  }

  saveemireceipt(erp:EmiRepaymentReceipt):Observable<EmiRepaymentReceipt>
  {
   return this.httpclient.post<EmiRepaymentReceipt>("http://localhost:9093/saveEmi",erp);
  }

  getInvoice(invoiceId:number):Observable<EmiRepaymentReceipt>
  {
    return this.httpclient.get<EmiRepaymentReceipt>("http://localhost:9093/getInvoice"+"/"+invoiceId);
  }

}
